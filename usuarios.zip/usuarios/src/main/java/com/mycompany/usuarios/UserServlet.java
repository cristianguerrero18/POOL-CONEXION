package com.mycompany.usuarios;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

@WebServlet("/usuario")
public class UserServlet extends HttpServlet {
    private DataSource dataSource;

    @Override
    public void init() throws ServletException {
        try {
            Context initContext = new InitialContext();
            dataSource = (DataSource) initContext.lookup("jdbc/usuarios");
        } catch (Exception e) {
            throw new ServletException("Cannot initialize DataSource", e);
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        List<Usuario> usuarios = new ArrayList<>();
        try (Connection conn = dataSource.getConnection();
             PreparedStatement stmt = conn.prepareStatement("SELECT * FROM usuarios_simples")) {
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                usuarios.add(new Usuario(
                    rs.getInt("id_usuario"),
                    rs.getString("nombre_completo"),
                    rs.getString("email")
                ));
            }
        } catch (SQLException e) {
            throw new ServletException("Error retrieving users", e);
        }

        request.setAttribute("usuarios", usuarios); // Changed attribute name to match JSP
        request.getRequestDispatcher("/Usuarios.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String nombre = request.getParameter("nombre");
        String email = request.getParameter("email");

        // Basic input validation
        if (nombre == null || email == null || nombre.trim().isEmpty() || email.trim().isEmpty()) {
            request.setAttribute("error", "Nombre and email are required");
            doGet(request, response);
            return;
        }

        try (Connection conn = dataSource.getConnection();
             PreparedStatement stmt = conn.prepareStatement(
                 "INSERT INTO usuarios_simples (nombre_completo, email) VALUES (?, ?)")) {
            stmt.setString(1, nombre);
            stmt.setString(2, email);
            stmt.executeUpdate();
        } catch (SQLException e) {
            throw new ServletException("Error inserting user", e);
        }

        response.sendRedirect("usuario"); // Consistent with WebServlet mapping
    }
}